$ git init
$ git add Skript_1.1.pdf
$ git add Skript_1.2.pdf
$ git add Skript_1.3.pdf
$ git add Skript_1.4.pdf
$ git add Skript_1.5.pdf
$ git add Skript_1.6.pdf
$ git add Skript_1.7.pdf
$ git commit -m "Repository erstellt"
§ git status
